// Datos de demostración de NEXO (sin backend). Las "fotos" son avatares generados con degradados.
window.NEXO_DATA = {
  me: {
    id: "me",
    name: "Criss Zayith",
    age: 39,
    bio: "Música, tecnología, videojuegos y fe en Yahshúa.",
    verified: true,
    stats: { seguidores: 842, megusta: 312, conexiones: 127 },
    intereses: ["punk", "gta", "tecnologia", "cine", "musica", "biblia"],
    personalidad: ["Tranquilo", "Creativo", "Aventurero"],
    hue: 215
  },
  intereses: {
    punk:       { icon: "🎸", label: "Punk Rock" },
    gta:        { icon: "🎮", label: "GTA" },
    tecnologia: { icon: "💻", label: "Tecnología" },
    cine:       { icon: "🎬", label: "Cine" },
    musica:     { icon: "🎵", label: "Música" },
    biblia:     { icon: "📖", label: "Biblia" },
    foto:       { icon: "📷", label: "Fotografía" },
    gaming:     { icon: "🕹️", label: "Gaming" },
    rock:       { icon: "🤘", label: "Rock" },
    hardcore:   { icon: "🔥", label: "Hardcore" }
  },
  personas: [
    { id: "p1", name: "Valentina", age: 28, city: "Puerto Montt, Chile", verified: true, hue: 330,
      intereses: ["punk", "gta", "tecnologia", "cine", "foto"], base: 87,
      bio: "Tatuajes, ruido y buen café." },
    { id: "p2", name: "Matías", age: 31, city: "Santiago, Chile", verified: true, hue: 190,
      intereses: ["punk", "gta", "tecnologia", "gaming"], base: 92,
      bio: "Dev de día, bajista de noche." },
    { id: "p3", name: "Camila", age: 26, city: "Valparaíso, Chile", verified: false, hue: 285,
      intereses: ["hardcore", "tecnologia", "cine", "musica"], base: 85,
      bio: "Hardcore, PC gaming y películas raras." },
    { id: "p4", name: "Sofía", age: 29, city: "Concepción, Chile", verified: true, hue: 15,
      intereses: ["punk", "gta", "tecnologia", "foto"], base: 92,
      bio: "Fotografío conciertos." },
    { id: "p5", name: "Diego", age: 33, city: "Temuco, Chile", verified: false, hue: 150,
      intereses: ["musica", "gaming", "rock"], base: 89,
      bio: "Producción musical y gaming." },
    { id: "p6", name: "Javiera", age: 27, city: "La Serena, Chile", verified: true, hue: 45,
      intereses: ["rock", "foto", "cine"], base: 78,
      bio: "Cine de culto y rock clásico." }
  ],
  posts: [
    { id: "s1", text: "Una buena noche de rock 🤘🎸", tags: ["#PunkRock", "#Concierto", "#Vida"],
      when: "Hace 2 h", likes: 324, comments: 48, image: "concert" },
    { id: "s2", text: "GTA V siempre ❤️", tags: [], when: "Hace 1 día", likes: 96, comments: 12, image: null }
  ],
  chats: [
    { id: "p1", last: "Ambos tienen interés en punk. ¿Hablamos de música?", unread: 3 },
    { id: "p2", last: "Jaja justo estaba jugando GTA 😄", unread: 0 }
  ],
  comunidades: [
    { icon: "🎸", name: "Punk Chile", miembros: "24.892" },
    { icon: "🎮", name: "GTA Chile", miembros: "41.205" },
    { icon: "💻", name: "Tecnología Chile", miembros: "83.102" },
    { icon: "📷", name: "Fotografía", miembros: "15.382" }
  ]
};
