/* NEXO · prototipo web (sin dependencias). Pantallas: home, detalle (Like/Next), match, perfil, publicaciones, descubrir + chat. */
(function () {
  const D = window.NEXO_DATA;
  const $ = (s) => document.querySelector(s);
  const screen = $("#screen"), nav = $("#nav"), modal = $("#modal"), phone = $("#phone");

  const state = {
    tab: "home", view: "home", query: "Personas de Chile que hagan punk, les guste la tecnología y jueguen GTA…",
    queue: [], idx: 0, current: null, liked: {}, postTab: "mine", discoverIdx: 0,
    matchWith: null, chatWith: null, msgs: {}
  };

  const byId = (id) => D.personas.find((p) => p.id === id);
  const ini = (n) => n.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const pic = (p, cls = "") => `<div class="pic ${cls}" style="--h:${p.hue}"><span class="ini">${ini(p.name)}</span></div>`;
  const tag = (k, sel) => `<span class="tag ${sel ? "sel" : ""}">${D.intereses[k].icon} ${D.intereses[k].label}</span>`;
  const common = (p) => p.intereses.filter((i) => D.me.intereses.includes(i));
  const compat = (p) => Math.min(99, p.base);

  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast"; t.textContent = msg; phone.appendChild(t);
    setTimeout(() => t.remove(), 1800);
  }

  /* ---- Búsqueda: interpreta palabras clave y ordena por coincidencias ---- */
  const KEYS = { punk: "punk", gta: "gta", tecnolog: "tecnologia", cine: "cine", musica: "musica", música: "musica",
    foto: "foto", gaming: "gaming", rock: "rock", hardcore: "hardcore", biblia: "biblia" };
  function search(q) {
    const low = q.toLowerCase(), wanted = new Set();
    Object.keys(KEYS).forEach((k) => low.includes(k) && wanted.add(KEYS[k]));
    if (!wanted.size) return [...D.personas].sort((a, b) => b.base - a.base);
    return [...D.personas].map((p) => {
      const hits = p.intereses.filter((i) => wanted.has(i)).length;
      return { p, s: hits / wanted.size };
    }).sort((a, b) => b.s - a.s || b.p.base - a.p.base).map((x) => x.p);
  }

  /* ---- NAV ---- */
  function renderNav() {
    const items = [["home", "🏠", "Inicio"], ["discover", "🧭", "Descubrir"], ["create", "+", ""], ["chat", "💬", "Chat"], ["profile", "👤", "Perfil"]];
    nav.innerHTML = items.map(([id, ic, lb]) => id === "create"
      ? `<button class="plus" data-go="create" aria-label="Publicar">+</button>`
      : `<button data-go="${id}" class="${state.tab === id ? "active" : ""}"><span class="ic">${ic}</span>${lb}${id === "chat" ? '<span class="badge">3</span>' : ""}</button>`).join("");
    nav.style.display = ["detail", "match"].includes(state.view) ? "none" : "flex";
  }

  /* ---- 1. HOME ---- */
  function home() {
    const list = search(state.query).slice(0, 6);
    state.queue = list;
    screen.innerHTML = `
      <div class="topbar"><button class="iconbtn" data-act="menu">☰</button><div class="logo">NEXO</div><button class="iconbtn" data-act="bell">🔔</button></div>
      <h1 class="hero">¿A quién quieres<br>conocer?</h1>
      <form class="search" id="sf"><span>🔍</span><input id="q" value="${state.query}" aria-label="Buscar personas"><button class="go" type="submit">→</button></form>
      <h2>✦ Perfiles compatibles para ti</h2>
      <div class="row">${list.slice(0, 5).map((p, i) => `
        <div class="mini ${i < 2 ? "hot" : "warm"}" data-open="${p.id}">${pic(p, "")}<div class="pct">${compat(p)}%<small>Compatible</small></div></div>`).join("")}</div>
      <h2>También puedes…</h2>
      <div class="quick">
        <button data-go="communities"><span class="e">🧩</span>Explorar Comunidades</button>
        <button data-go="create"><span class="e">📸</span>Publicar Contenido</button>
        <button data-act="surprise"><span class="e">🎲</span>Modo Sorpresa</button>
      </div>`;
    $("#sf").onsubmit = (e) => { e.preventDefault(); state.query = $("#q").value; home(); toast("Buscando coincidencias…"); };
  }

  /* ---- 2. DETALLE LIKE / NEXT ---- */
  function openDetail(id) {
    state.current = byId(id); state.view = "detail";
    state.idx = Math.max(0, state.queue.findIndex((p) => p.id === id));
    detail();
  }
  function detail() {
    const p = state.current, c = common(p);
    screen.innerHTML = `<div class="detail">
      <div class="photo">${pic(p)}
        <button class="back" data-act="back">←</button>
        <div class="count">${state.idx + 1} de ${state.queue.length}</div>
        <div class="compat">♡ ${compat(p)}%<small>Compatible</small></div></div>
      <div class="info"><h3>${p.name}, ${p.age} ${p.verified ? '<span class="verified">✔</span>' : ""}</h3>
        <div class="city">📍 ${p.city}</div>
        <p class="muted" style="margin-bottom:10px">${p.bio}</p>
        <div class="tags">${p.intereses.map((k) => tag(k, c.includes(k))).join("")}</div></div>
      <div class="actions">
        <button class="act next" data-act="next"><span class="c">✕</span>Next</button>
        <button class="act like" data-act="like"><span class="c">♥</span>Like</button></div></div>`;
    renderNav();
  }
  function advance() {
    state.idx++;
    if (state.idx >= state.queue.length) { toast("No hay más perfiles por ahora"); state.view = "home"; state.tab = "home"; return go("home"); }
    state.current = state.queue[state.idx]; detail();
  }
  function like() {
    const p = state.current; state.liked[p.id] = true;
    // Demo: si compatibilidad ≥ 85 la otra persona también te dio like.
    if (compat(p) >= 85) { state.matchWith = p; state.view = "match"; match(); } else { toast("Like enviado ♥"); advance(); }
  }

  /* ---- 3. MATCH ---- */
  function match() {
    const p = state.matchWith, c = common(p);
    screen.innerHTML = `<div class="match">
      <span class="spark" style="left:22%;top:20px">✦</span><span class="spark" style="right:18%;top:70px">✦</span><span class="spark" style="left:12%;top:120px">♥</span>
      <h1>¡NEXO!</h1><div class="sub">También se gustaron</div>
      <div class="pair">${pic(p)}<span class="heart">💜</span>${pic(D.me)}</div>
      <div class="names"><div><b>${p.name}</b><span class="muted">${p.age} años</span></div><div><b>${D.me.name}</b><span class="muted">${D.me.age} años</span></div></div>
      <div class="meter">Tienen <b>${compat(p)}%</b> de compatibilidad<div class="bar"><i style="width:${compat(p)}%"></i></div></div>
      <div>Coinciden en:</div>
      <div class="coinc">${c.slice(0, 4).map((k) => `<div><span>${D.intereses[k].icon}</span>${D.intereses[k].label.replace(" Rock", "")}</div>`).join("")}</div>
      <button class="btn primary" data-act="startchat">💬 Iniciar Chat</button>
      <button class="btn ghost" data-act="keep">Seguir buscando</button></div>`;
    renderNav();
  }

  /* ---- 4. PERFIL ---- */
  function profile() {
    const m = D.me;
    screen.innerHTML = `
      <div class="topbar"><button class="iconbtn" data-go="home">←</button><b>Mi Perfil</b><button class="iconbtn" data-act="settings">⚙️</button></div>
      <div class="ph">${pic(m)}<div><h3>${m.name} <span class="verified">✔</span></h3><p>“${m.bio}”</p></div></div>
      <div class="stats"><div><b>${m.stats.seguidores}</b><span>Seguidores</span></div><div><b>${m.stats.megusta}</b><span>Me gusta</span></div><div><b>${m.stats.conexiones}</b><span>Conexiones</span></div></div>
      <div class="sechead"><h2>Mis Intereses</h2><button class="link" data-act="edit">Editar</button></div>
      <div class="tags">${m.intereses.map((k) => tag(k)).join("")}</div>
      <h2>Mi Personalidad</h2>
      <div class="tags">${m.personalidad.map((x) => `<span class="tag">✨ ${x}</span>`).join("")}</div>
      <h2>Lo que busco</h2>
      <div class="tags">${["Amistad", "Conversar", "Compartir intereses", "Gaming", "Música"].map((x) => `<span class="tag sel">${x}</span>`).join("")}</div>
      <h2>Mis comunidades</h2>
      <div class="tags">${D.comunidades.map((c) => `<span class="tag">${c.icon} ${c.name}</span>`).join("")}</div>
      <button class="btn primary" data-go="posts" style="margin-top:20px">📷 Ver mis publicaciones</button>`;
  }

  /* ---- 5. PUBLICACIONES ---- */
  function posts() {
    const list = state.postTab === "mine" ? D.posts : D.posts.filter((p) => state.liked["post" + p.id]);
    screen.innerHTML = `
      <div class="tabs"><button data-ptab="mine" class="${state.postTab === "mine" ? "on" : ""}">Mis Publicaciones</button><button data-ptab="liked" class="${state.postTab === "liked" ? "on" : ""}">Me Gustan</button></div>
      ${list.length ? list.map((p) => `
        <article class="post">
          <div class="head">${pic(D.me)}<div><b>${D.me.name}</b><span class="muted">${p.when} · 🌐</span></div></div>
          <div>${p.text}</div><div class="hash">${p.tags.join(" ")}</div>
          ${p.image ? `<div class="concert"><b>PUNK'S<br>NOT DEAD</b></div>` : ""}
          <div class="pbar">
            <button data-likepost="${p.id}" class="${state.liked["post" + p.id] ? "liked" : ""}">${state.liked["post" + p.id] ? "❤️" : "🤍"} ${p.likes + (state.liked["post" + p.id] ? 1 : 0)}</button>
            <button>💬 ${p.comments}</button><button data-act="share">↗ Compartir</button></div>
        </article>`).join("") : '<p class="muted" style="padding:30px;text-align:center">Aún no te ha gustado nada.</p>'}
      <button class="fab" data-go="create">+</button>`;
  }

  /* ---- 6. DESCUBRIR ---- */
  function discover() {
    const list = [...D.personas].sort((a, b) => b.base - a.base);
    const a = list[state.discoverIdx % list.length], b = list[(state.discoverIdx + 1) % list.length];
    const card = (p) => `<div class="dcard" data-open="${p.id}">${pic(p)}<div class="pct">${compat(p)}%</div>
      <div class="ov">Coinciden en:<br>${common(p).slice(0, 3).map((k) => D.intereses[k].label).join(", ") || "Nuevos intereses"}</div></div>`;
    state.queue = list;
    screen.innerHTML = `
      <div class="dhead"><h2>Descubrir Personas</h2><button class="iconbtn" data-act="filters">⚙️</button></div>
      <div class="aff"><span>Afinidad con tus intereses</span><b>${compat(a)}%</b></div>
      <div class="grid2">${card(a)}${card(b)}</div>
      <div class="dual"><button class="nx" data-act="dnext">✕ Next</button><button class="lk" data-act="dlike">♥ Like</button></div>
      <button class="more" data-act="dmore">👥 Ver más personas compatibles ↓</button>`;
  }

  /* ---- Extra: Chat, Crear, Comunidades ---- */
  function chat() {
    if (state.chatWith) return conversation();
    screen.innerHTML = `<div class="topbar"><b style="font-size:22px">Chat</b></div>` +
      D.chats.map((c) => { const p = byId(c.id); return `<div class="chatrow" data-chat="${p.id}">${pic(p)}<div class="t"><b>${p.name}</b><span>${c.last}</span></div>${c.unread ? `<span class="badge" style="position:static">${c.unread}</span>` : ""}</div>`; }).join("");
  }
  function conversation() {
    const p = byId(state.chatWith), c = common(p).slice(0, 2).map((k) => D.intereses[k].label).join(" y ");
    const m = state.msgs[p.id] || (state.msgs[p.id] = [{ me: false, t: "¡Hola! Vi que también te gusta " + (c || "la música") + " 😄" }]);
    screen.innerHTML = `<div class="topbar"><button class="iconbtn" data-act="chats">←</button><b>${p.name}</b><span></span></div>
      <div class="ai">✨ Tenemos algo en común: ${c || "varios intereses"}. ¿Quieres iniciar hablando de música?</div>
      ${m.map((x) => `<div class="bubble ${x.me ? "out" : "in"}">${x.t}</div>`).join("")}
      <form class="composer" id="cf"><input id="ci" placeholder="Escribe un mensaje…"><button>➤</button></form>`;
    $("#cf").onsubmit = (e) => { e.preventDefault(); const v = $("#ci").value.trim(); if (v) { m.push({ me: true, t: v }); conversation(); } };
  }
  function create() {
    modal.classList.remove("hidden");
    modal.innerHTML = `<div class="sheet"><h3>Publicar</h3><textarea id="pt" placeholder="¿Qué quieres compartir?"></textarea>
      <div class="tags" style="margin-bottom:12px"><span class="tag">📷 Foto</span><span class="tag">🎥 Video</span><span class="tag">🎵 Música</span><span class="tag">🎮 Gaming</span></div>
      <button class="btn primary" data-act="publish">Publicar</button><button class="btn ghost" data-act="close">Cancelar</button></div>`;
  }
  function communities() {
    screen.innerHTML = `<div class="topbar"><button class="iconbtn" data-go="home">←</button><b>Comunidades</b><span></span></div>` +
      D.comunidades.map((c) => `<div class="chatrow"><div class="pic round" style="--h:${(c.name.length * 37) % 360};width:52px;height:52px"><span class="ini" style="font-size:24px">${c.icon}</span></div><div class="t"><b>${c.name}</b><span>${c.miembros} miembros</span></div><button class="tag sel" data-act="join">Unirme</button></div>`).join("");
  }

  /* ---- Router ---- */
  function go(view) {
    state.view = view; if (["home", "discover", "chat", "profile"].includes(view)) state.tab = view;
    if (view !== "chat") state.chatWith = null;
    ({ home, discover, chat, profile, posts, communities, create }[view] || home)();
    if (view !== "create") { modal.classList.add("hidden"); screen.scrollTop = 0; }
    renderNav();
  }

  /* ---- Eventos ---- */
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-go],[data-act],[data-open],[data-chat],[data-ptab],[data-likepost]");
    if (!t) return;
    if (t.dataset.go) return go(t.dataset.go);
    if (t.dataset.open) return openDetail(t.dataset.open);
    if (t.dataset.chat) { state.chatWith = t.dataset.chat; return conversation(); }
    if (t.dataset.ptab) { state.postTab = t.dataset.ptab; return posts(); }
    if (t.dataset.likepost) { const k = "post" + t.dataset.likepost; state.liked[k] = !state.liked[k]; return posts(); }
    switch (t.dataset.act) {
      case "back": return go(state.tab === "discover" ? "discover" : "home");
      case "next": return advance();
      case "like": return like();
      case "keep": state.view = "detail"; return advance();
      case "startchat": state.tab = "chat"; state.view = "chat"; state.chatWith = state.matchWith.id; renderNav(); return conversation();
      case "surprise": { const r = D.personas[Math.floor(Math.random() * D.personas.length)]; state.queue = [r]; return openDetail(r.id); }
      case "dnext": state.discoverIdx += 2; return discover();
      case "dlike": toast("Like enviado ♥"); state.discoverIdx += 2; return discover();
      case "dmore": toast("Cargando más perfiles…"); state.discoverIdx += 2; return discover();
      case "chats": state.chatWith = null; return chat();
      case "close": return go(state.tab);
      case "publish": { const v = ($("#pt") || {}).value; if (v && v.trim()) D.posts.unshift({ id: "n" + Date.now(), text: v, tags: [], when: "Ahora", likes: 0, comments: 0, image: null }); modal.classList.add("hidden"); toast("Publicado ✔"); state.postTab = "mine"; return go("posts"); }
      case "join": return toast("Te uniste a la comunidad ✔");
      case "edit": case "settings": case "menu": case "bell": case "filters": case "share": return toast("Disponible en la próxima versión");
    }
  });

  // Acceso directo a las 6 pantallas: index.html#home|detail|match|profile|posts|discover
  function boot() {
    const h = location.hash.replace("#", "");
    state.queue = search(state.query); state.current = state.queue[0]; state.matchWith = state.queue[0];
    if (h === "detail") { state.view = "detail"; return detail(); }
    if (h === "match") { state.view = "match"; return match(); }
    go(["home", "profile", "posts", "discover", "chat"].includes(h) ? h : "home");
  }
  // Botón "atrás" de Android: devuelve true si la app manejó el gesto.
  window.nexoBack = function () {
    if (!modal.classList.contains("hidden")) { go(state.tab); return true; }
    if (state.view === "detail") { go(state.tab === "discover" ? "discover" : "home"); return true; }
    if (state.view === "match") { go("home"); return true; }
    if (["posts", "communities"].includes(state.view)) { go("profile"); return true; }
    if (state.chatWith) { state.chatWith = null; go("chat"); return true; }
    if (state.view !== "home") { go("home"); return true; }
    return false;
  };
  window.addEventListener("hashchange", boot);
  boot();
})();
